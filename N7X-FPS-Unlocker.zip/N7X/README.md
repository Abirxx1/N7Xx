# N7X FPS Unlocker (Farlight 84 advisor)

Reads device capabilities and recommends Farlight 84 frame rate and graphics settings.
It does NOT modify game files, bypass anti-cheat, use root, or change FPS. Set the final values inside the game.
Display refresh rate (Hz) is not game FPS.

## Build (Android Studio)
1. Install Android Studio (Koala or newer) with JDK 17.
2. File > Open > select this folder. Let Gradle sync (needs internet the first time).
3. Run unit tests: `./gradlew test` (or right-click the `test` folder > Run).
4. Connect the phone (USB debugging on) and press Run.

## Debug APK
`./gradlew assembleDebug`
Output: `app/build/outputs/apk/debug/app-debug.apk`
Install: `adb install -r app-debug.apk`

## Release APK
1. Create a key: `keytool -genkey -v -keystore n7x.jks -keyalg RSA -keysize 2048 -validity 10000 -alias n7x`
2. Android Studio: Build > Generate Signed App Bundle / APK > APK > pick n7x.jks > release.
Keep the .jks file private and backed up.

## Notes
- If `gradlew` is missing, Android Studio creates it on sync, or run `gradle wrapper --gradle-version 8.7`.
- Game package id used for launch: `com.farlightgames.igame.gp` (verify in Play Store URL if launch fails).
- Realme GT Master Edition (SM7325): expected tier Mid-range, recommended 60 FPS, 90 experimental, 120 not recommended.
