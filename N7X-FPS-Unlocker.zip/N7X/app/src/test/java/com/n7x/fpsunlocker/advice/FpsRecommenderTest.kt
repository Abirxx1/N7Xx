package com.n7x.fpsunlocker.advice

import com.n7x.fpsunlocker.device.DisplayInfo
import com.n7x.fpsunlocker.device.SocInfo
import org.junit.Assert.assertEquals
import org.junit.Test

class FpsRecommenderTest {

    private val gtMasterSoc = SocInfo("QTI", "SM7325")
    private val display120 = DisplayInfo(120f, listOf(60, 120), 2400, 1080, 409)
    private val display60 = DisplayInfo(60f, listOf(60), 2400, 1080, 409)

    private fun verdictFor(a: Assessment, fps: Int) = a.profiles.first { it.fps == fps }.verdict

    @Test
    fun snapdragon778g_120hz_recommends60() {
        val a = FpsRecommender.assess(gtMasterSoc, 7600, display120, 0)
        assertEquals(Tier.MID, a.tier)
        assertEquals(60, a.ceilingFps)
        assertEquals(Verdict.SAFE, verdictFor(a, 30))
        assertEquals(Verdict.SAFE, verdictFor(a, 40))
        assertEquals(Verdict.RECOMMENDED, verdictFor(a, 60))
        assertEquals(Verdict.EXPERIMENTAL, verdictFor(a, 90))
        assertEquals(Verdict.NOT_RECOMMENDED, verdictFor(a, 120))
    }

    @Test
    fun display60Hz_blocksHigherProfiles() {
        val a = FpsRecommender.assess(gtMasterSoc, 7600, display60, 0)
        assertEquals(Verdict.UNAVAILABLE, verdictFor(a, 90))
        assertEquals(Verdict.UNAVAILABLE, verdictFor(a, 120))
    }

    @Test
    fun severeThermals_lowerTheCeiling() {
        val a = FpsRecommender.assess(gtMasterSoc, 7600, display120, 3)
        assertEquals(40, a.ceilingFps)
    }

    @Test
    fun lowRam_isEntryTier() {
        val a = FpsRecommender.assess(SocInfo("X", "UNKNOWN"), 3000, display120, 0)
        assertEquals(Tier.LOW, a.tier)
    }

    @Test
    fun unknownChip_fallsBackToRam() {
        assertEquals(Tier.HIGH, FpsRecommender.estimateTier(SocInfo("X", "UNKNOWN"), 12000).first)
        assertEquals(Tier.MID, FpsRecommender.estimateTier(SocInfo("X", "UNKNOWN"), 8000).first)
    }
}
