package com.n7x.fpsunlocker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.n7x.fpsunlocker.ui.N7XApp
import com.n7x.fpsunlocker.ui.N7XTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            N7XTheme { N7XApp() }
        }
    }
}
