package com.n7x.fpsunlocker.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val N7XBlack = Color(0xFF000000)
val Panel = Color(0xFF0C0C16)
val Outline = Color(0xFF2A2A44)
val NeonBlue = Color(0xFF00E5FF)
val NeonPurple = Color(0xFFB026FF)
val TextDim = Color(0xFF9AA0B5)
val Warn = Color(0xFFFF4D6D)

@Composable
fun N7XTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonBlue,
            secondary = NeonPurple,
            background = N7XBlack,
            surface = Panel,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
