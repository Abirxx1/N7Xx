package com.n7x.fpsunlocker.device

data class SocInfo(val manufacturer: String, val model: String)

data class CpuInfo(val cores: Int, val maxFreqMhz: Int?, val abi: String)

data class DisplayInfo(
    val currentHz: Float,
    val supportedHz: List<Int>,
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int
) {
    val maxHz: Int get() = supportedHz.maxOrNull() ?: currentHz.toInt()
}

data class DeviceSnapshot(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val soc: SocInfo,
    val cpu: CpuInfo,
    val gpuRenderer: String,
    val totalRamMb: Long,
    val display: DisplayInfo
)

data class LiveStats(
    val availRamMb: Long,
    val usedPercent: Int,
    val thermalStatus: Int,
    val thermalLabel: String,
    val batteryTempC: Float?,
    val batteryPercent: Int
)
