package com.n7x.fpsunlocker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.n7x.fpsunlocker.advice.FpsRecommender
import com.n7x.fpsunlocker.advice.ProfileAdvice
import com.n7x.fpsunlocker.advice.Verdict
import com.n7x.fpsunlocker.device.DeviceInfoProvider
import com.n7x.fpsunlocker.device.DeviceSnapshot
import com.n7x.fpsunlocker.device.LiveStats
import com.n7x.fpsunlocker.util.Actions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun N7XApp() {
    val ctx = LocalContext.current
    val provider = remember { DeviceInfoProvider(ctx.applicationContext) }
    var snap by remember { mutableStateOf<DeviceSnapshot?>(null) }
    var live by remember { mutableStateOf<LiveStats?>(null) }
    var selected by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) { snap = withContext(Dispatchers.Default) { provider.snapshot() } }
    LaunchedEffect(Unit) {
        while (true) {
            live = provider.live()
            delay(2000)
        }
    }

    Surface(Modifier.fillMaxSize(), color = N7XBlack) {
        val s = snap
        if (s == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Detecting device...", color = NeonBlue)
            }
            return@Surface
        }
        val assessment = remember(s, live?.thermalStatus) {
            FpsRecommender.assess(s.soc, s.totalRamMb, s.display, live?.thermalStatus ?: 0)
        }
        val sel = selected ?: assessment.ceilingFps
        val selectedProfile = assessment.profiles.first { it.fps == sel }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Header() }
            item { HonestyCard() }
            item { DeviceCard(s) }
            item { DisplayCard(s) }
            item { LiveCard(live, s.totalRamMb) }
            item {
                NeonCard {
                    SectionTitle("FPS profiles")
                    Text(
                        "Estimated tier: ${assessment.tier.label} (${assessment.tierReason})",
                        color = TextDim, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    assessment.profiles.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { p ->
                                ProfileCard(p, p.fps == sel, Modifier.weight(1f)) { selected = p.fps }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            item { ProfileDetail(selectedProfile) }
            item { LaunchCard() }
            item { GuideCard() }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.padding(top = 8.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("N7X", color = NeonBlue, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(8.dp))
            Text("FPS UNLOCKER", color = NeonPurple, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Text("Farlight 84 optimization advisor", color = TextDim, fontSize = 13.sp)
    }
}

@Composable
private fun HonestyCard() {
    NeonCard {
        SectionTitle("What this app does")
        Text(
            "It reads your hardware and recommends settings to try in Farlight 84. It does not modify game files, " +
                "bypass protections, or change your FPS. Display refresh rate (Hz) is how often the screen updates. " +
                "Game FPS is how many frames the game renders. They are different numbers.",
            color = TextDim, fontSize = 13.sp, lineHeight = 19.sp
        )
    }
}

@Composable
private fun DeviceCard(s: DeviceSnapshot) {
    NeonCard {
        SectionTitle("Device")
        StatRow("Model", "${s.manufacturer} ${s.model}")
        StatRow("Android", "${s.androidRelease} (API ${s.sdkInt})")
        StatRow("Chipset", "${s.soc.manufacturer} ${s.soc.model}")
        StatRow("CPU", "${s.cpu.cores} cores" + (s.cpu.maxFreqMhz?.let { ", up to $it MHz" } ?: "") + ", ${s.cpu.abi}")
        StatRow("GPU", s.gpuRenderer)
        StatRow("Total RAM", "${s.totalRamMb} MB")
    }
}

@Composable
private fun DisplayCard(s: DeviceSnapshot) {
    var running by remember { mutableStateOf(false) }
    var measured by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(running) {
        if (running) {
            var frames = 0
            var start = -1L
            while (true) {
                val t = withFrameNanos { it }
                if (start < 0) start = t else frames++
                if (t - start >= 3_000_000_000L) {
                    measured = (frames * 1_000_000_000.0 / (t - start)).roundToInt()
                    break
                }
            }
            running = false
        }
    }
    NeonCard {
        SectionTitle("Display (refresh rate, not game FPS)")
        StatRow("Resolution", "${s.display.widthPx} x ${s.display.heightPx} @ ${s.display.densityDpi} dpi")
        StatRow("Current mode", "${s.display.currentHz.roundToInt()} Hz")
        StatRow("Supported modes", s.display.supportedHz.joinToString(", ") { "$it Hz" })
        StatRow("Measured (this app)", measured?.let { "$it Hz" } ?: "Not tested")
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { if (!running) running = true }) {
            Text(if (running) "Measuring..." else "Run 3-second display test", color = NeonBlue)
        }
        Text(
            "This measures how often your screen updated while this app was drawing. It says nothing about Farlight 84's FPS. " +
                "Android does not let a normal app read another app's frame rate.",
            color = TextDim, fontSize = 11.sp, lineHeight = 16.sp
        )
    }
}

@Composable
private fun LiveCard(live: LiveStats?, totalMb: Long) {
    NeonCard {
        SectionTitle("Live performance")
        if (live == null) {
            Text("Reading...", color = TextDim)
            return@NeonCard
        }
        StatRow("RAM in use", "${live.usedPercent}% (${totalMb - live.availRamMb} / $totalMb MB)")
        LinearProgressIndicator(
            progress = { live.usedPercent / 100f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = if (live.usedPercent > 85) Warn else NeonBlue,
            trackColor = Outline
        )
        Spacer(Modifier.height(8.dp))
        StatRow("Thermal state", live.thermalLabel)
        StatRow("Battery", (if (live.batteryPercent >= 0) "${live.batteryPercent}%" else "n/a") +
            (live.batteryTempC?.let { ", ${"%.1f".format(it)} C" } ?: ""))
    }
}

@Composable
private fun ProfileCard(p: ProfileAdvice, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(Panel)
            .border(if (selected) 2.dp else 1.dp, if (selected) NeonBlue else Outline, shape)
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${p.fps}", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.width(4.dp))
            Text("FPS", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(p.verdict.label, color = verdictColor(p.verdict), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProfileDetail(p: ProfileAdvice) {
    NeonCard {
        SectionTitle("${p.fps} FPS profile")
        Text(p.verdict.label, color = verdictColor(p.verdict), fontWeight = FontWeight.Bold)
        Text(p.summary, color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        val g = p.graphics
        StatRow("Graphics quality", g.graphicsQuality)
        StatRow("Resolution", g.resolution)
        StatRow("Shadow quality", g.shadowQuality)
        StatRow("Anti-aliasing", g.antiAliasing)
        StatRow("Rendering quality", g.renderingQuality)
        StatRow("Frame rate", g.frameRate)
        Spacer(Modifier.height(10.dp))
        p.notes.forEach {
            Text("\u2022 $it", color = TextDim, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        Text(
            "Setting names in the game may differ by version. Treat these as starting points and verify in a real match.",
            color = TextDim, fontSize = 11.sp
        )
    }
}

@Composable
private fun LaunchCard() {
    val ctx = LocalContext.current
    val installed = remember { Actions.isGameInstalled(ctx) }
    NeonCard {
        SectionTitle("Launch")
        Text(if (installed) "Farlight 84 is installed." else "Farlight 84 was not found on this phone.", color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { Actions.launchGame(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (installed) "Launch Farlight 84" else "Open Play Store page")
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { Actions.pinGameShortcut(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text("Add launch shortcut to home screen", color = NeonBlue)
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { Actions.openDisplaySettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
            Text("Open display settings", color = NeonBlue)
        }
    }
}

@Composable
private fun GuideCard() {
    val tips = listOf(
        "Set the phone's display refresh to the highest option in Settings > Display before playing.",
        "Close background apps, especially social and video apps.",
        "Turn off battery saver. Use your phone's game or performance mode if it has one.",
        "Remove thick cases and avoid charging while playing to reduce heat.",
        "Lower shadows and anti-aliasing first. They cost the most FPS for the least visual loss.",
        "If the frame rate dips, drop one profile step instead of raising quality.",
        "Judge results in a real match. Use the game's own FPS display if it offers one.",
        "Ignore apps that claim to unlock FPS or ask for root. They cannot change a game's limits and can risk your account."
    )
    NeonCard {
        SectionTitle("Performance guide")
        tips.forEach {
            Text("\u2022 $it", color = TextDim, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(bottom = 5.dp))
        }
    }
}

@Composable
private fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Panel)
            .border(1.dp, Brush.horizontalGradient(listOf(NeonBlue, NeonPurple)), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = NeonBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextDim, fontSize = 13.sp, modifier = Modifier.weight(0.4f))
        Text(value, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(0.6f))
    }
}

private fun verdictColor(v: Verdict): Color = when (v) {
    Verdict.RECOMMENDED -> NeonBlue
    Verdict.SAFE -> Color(0xFF8FB8FF)
    Verdict.EXPERIMENTAL -> NeonPurple
    Verdict.NOT_RECOMMENDED -> Warn
    Verdict.UNAVAILABLE -> TextDim
}
