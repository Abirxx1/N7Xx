package com.n7x.fpsunlocker.advice

import com.n7x.fpsunlocker.device.DisplayInfo
import com.n7x.fpsunlocker.device.SocInfo

enum class Tier(val label: String) { LOW("Entry"), MID("Mid-range"), HIGH("Flagship") }

enum class Verdict(val label: String) {
    RECOMMENDED("Recommended"),
    SAFE("Safe"),
    EXPERIMENTAL("Experimental"),
    NOT_RECOMMENDED("Not recommended"),
    UNAVAILABLE("Display can't do this")
}

data class GraphicsAdvice(
    val graphicsQuality: String,
    val resolution: String,
    val shadowQuality: String,
    val antiAliasing: String,
    val frameRate: String,
    val renderingQuality: String
)

data class ProfileAdvice(
    val fps: Int,
    val verdict: Verdict,
    val summary: String,
    val notes: List<String>,
    val graphics: GraphicsAdvice
)

data class Assessment(
    val tier: Tier,
    val tierReason: String,
    val ceilingFps: Int,
    val profiles: List<ProfileAdvice>
)

object FpsRecommender {

    val PROFILES = listOf(30, 40, 60, 90, 120)

    fun estimateTier(soc: SocInfo, totalRamMb: Long): Pair<Tier, String> {
        val model = soc.model.uppercase()
        val byChip: Tier? = when {
            model.startsWith("SM8") -> Tier.HIGH
            model.startsWith("SM7") -> Tier.MID
            model.startsWith("SM6") || model.startsWith("SM4") -> Tier.LOW
            else -> null
        }
        if (totalRamMb in 1..3900) return Tier.LOW to "Under 4 GB RAM"
        if (byChip != null) return byChip to "Chipset code ${soc.model}"
        val byRam = when {
            totalRamMb >= 11000 -> Tier.HIGH
            totalRamMb >= 5500 -> Tier.MID
            else -> Tier.LOW
        }
        return byRam to "Estimated from RAM (chipset ${soc.model.ifBlank { "unknown" }} not recognised)"
    }

    fun assess(soc: SocInfo, totalRamMb: Long, display: DisplayInfo, thermalStatus: Int): Assessment {
        val (tier, reason) = estimateTier(soc, totalRamMb)
        var ceilIdx = when (tier) {
            Tier.LOW -> 1
            Tier.MID -> 2
            Tier.HIGH -> 3
        }
        val hot = thermalStatus >= 3
        if (hot) ceilIdx = maxOf(0, ceilIdx - 1)
        val ceiling = PROFILES[ceilIdx]

        val profiles = PROFILES.mapIndexed { idx, fps ->
            val displayOk = fps <= display.maxHz + 1
            val cleanPacing = display.supportedHz.any { it % fps == 0 }
            val diff = idx - ceilIdx
            val verdict = when {
                !displayOk -> Verdict.UNAVAILABLE
                diff < 0 -> Verdict.SAFE
                diff == 0 -> Verdict.RECOMMENDED
                diff == 1 -> Verdict.EXPERIMENTAL
                else -> Verdict.NOT_RECOMMENDED
            }
            val notes = buildList {
                add("Set this inside Farlight 84 (Settings > Graphics). This app cannot change the game's frame rate.")
                if (!displayOk) add("Your display tops out at ${display.maxHz} Hz, so $fps FPS cannot be shown.")
                if (displayOk && !cleanPacing) {
                    add("Your display modes (${display.supportedHz.joinToString("/")} Hz) are not a clean multiple of $fps, so frame pacing may look uneven.")
                }
                if (verdict == Verdict.EXPERIMENTAL) add("Try a few matches. If frame rate or temperature drops, return to $ceiling FPS.")
                if (verdict == Verdict.NOT_RECOMMENDED) add("This chipset class is unlikely to sustain $fps FPS. Expect throttling.")
                if (fps >= 90) add("The game only shows frame rates that its own version allows for your device. Do not assume $fps FPS is offered.")
                if (fps == 120) add("Some phone game modes interpolate frames to reach 120. That is not the same as the game rendering 120 FPS.")
                if (hot) add("Your phone reports a high thermal state right now, so limits were lowered.")
            }
            val summary = when (verdict) {
                Verdict.RECOMMENDED -> "Best balance of smoothness and stability for this device."
                Verdict.SAFE -> "Stable with headroom. Good for battery life and cooler play."
                Verdict.EXPERIMENTAL -> "Possible, but may not hold under load."
                Verdict.NOT_RECOMMENDED -> "Unlikely to be sustained on this hardware."
                Verdict.UNAVAILABLE -> "Your display cannot show this frame rate."
            }
            ProfileAdvice(fps, verdict, summary, notes, graphicsFor(fps, ceilIdx - idx))
        }
        return Assessment(tier, reason, ceiling, profiles)
    }

    private fun graphicsFor(fps: Int, headroom: Int): GraphicsAdvice {
        val fpsText = "Pick the option that matches $fps FPS (names vary by game version)"
        return when {
            headroom >= 2 -> GraphicsAdvice("High", "High", "Medium", "On", fpsText, "Quality-focused")
            headroom == 1 -> GraphicsAdvice("Medium", "Medium", "Low", "On", fpsText, "Balanced")
            headroom == 0 -> GraphicsAdvice("Low to Medium", "Medium", "Low or Off", "Off", fpsText, "Performance")
            else -> GraphicsAdvice("Lowest", "Low", "Off", "Off", fpsText, "Smoothest")
        }
    }
}
