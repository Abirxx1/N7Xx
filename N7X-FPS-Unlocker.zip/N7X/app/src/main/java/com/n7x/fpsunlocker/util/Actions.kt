package com.n7x.fpsunlocker.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.n7x.fpsunlocker.R

object Actions {
    const val GAME_PACKAGE = "com.farlightgames.igame.gp"

    fun isGameInstalled(context: Context): Boolean =
        context.packageManager.getLaunchIntentForPackage(GAME_PACKAGE) != null

    fun launchGame(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        if (intent == null) {
            openStore(context)
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openStore(context: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$GAME_PACKAGE"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(market)
        } catch (e: ActivityNotFoundException) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$GAME_PACKAGE")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(web)
        }
    }

    fun openDisplaySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun pinGameShortcut(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        if (intent == null) {
            Toast.makeText(context, "Farlight 84 is not installed.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            Toast.makeText(context, "Your launcher does not support pinned shortcuts.", Toast.LENGTH_SHORT).show()
            return
        }
        val info = ShortcutInfoCompat.Builder(context, "farlight84_launch")
            .setShortLabel("Farlight 84")
            .setIntent(intent)
            .setIcon(IconCompat.createWithResource(context, R.drawable.ic_n7x))
            .build()
        ShortcutManagerCompat.requestPinShortcut(context, info, null)
    }
}
