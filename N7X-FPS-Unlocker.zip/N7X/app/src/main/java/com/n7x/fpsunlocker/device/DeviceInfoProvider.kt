package com.n7x.fpsunlocker.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import java.io.File
import kotlin.math.roundToInt

class DeviceInfoProvider(private val context: Context) {

    fun snapshot(): DeviceSnapshot = DeviceSnapshot(
        manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        model = Build.MODEL,
        androidRelease = Build.VERSION.RELEASE,
        sdkInt = Build.VERSION.SDK_INT,
        soc = readSoc(),
        cpu = readCpu(),
        gpuRenderer = readGpuRenderer(),
        totalRamMb = memoryInfo().totalMem / MB,
        display = readDisplay()
    )

    fun live(): LiveStats {
        val mi = memoryInfo()
        val total = mi.totalMem / MB
        val avail = mi.availMem / MB
        val used = if (total > 0) (((total - avail) * 100) / total).toInt() else 0
        val thermal = thermalStatus()
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempTenths = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return LiveStats(
            availRamMb = avail,
            usedPercent = used,
            thermalStatus = thermal,
            thermalLabel = thermalLabel(thermal),
            batteryTempC = if (tempTenths == Int.MIN_VALUE) null else tempTenths / 10f,
            batteryPercent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        )
    }

    private fun memoryInfo(): ActivityManager.MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun thermalStatus(): Int {
        if (Build.VERSION.SDK_INT < 29) return 0
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.currentThermalStatus
    }

    private fun thermalLabel(status: Int) = when (status) {
        0 -> "Normal"
        1 -> "Light"
        2 -> "Moderate"
        3 -> "Severe"
        4 -> "Critical"
        5 -> "Emergency"
        6 -> "Shutdown"
        else -> "Unknown"
    }

    private fun readSoc(): SocInfo {
        return if (Build.VERSION.SDK_INT >= 31) {
            SocInfo(Build.SOC_MANUFACTURER, Build.SOC_MODEL)
        } else {
            SocInfo(Build.MANUFACTURER, Build.HARDWARE)
        }
    }

    private fun readCpu(): CpuInfo {
        val cores = Runtime.getRuntime().availableProcessors()
        var maxKhz = 0
        for (i in 0 until cores) {
            val khz = try {
                File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toInt()
            } catch (e: Exception) {
                0
            }
            if (khz > maxKhz) maxKhz = khz
        }
        return CpuInfo(
            cores = cores,
            maxFreqMhz = if (maxKhz > 0) maxKhz / 1000 else null,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        )
    }

    private fun readDisplay(): DisplayInfo {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val rates = d.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        val mode = d.mode
        return DisplayInfo(
            currentHz = d.refreshRate,
            supportedHz = rates,
            widthPx = mode.physicalWidth,
            heightPx = mode.physicalHeight,
            densityDpi = context.resources.displayMetrics.densityDpi
        )
    }

    private fun readGpuRenderer(): String {
        return try {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val version = IntArray(2)
            EGL14.eglInitialize(display, version, 0, version, 1)
            val attrs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, count, 0)
            val ctx = EGL14.eglCreateContext(
                display, configs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            val surf = EGL14.eglCreatePbufferSurface(
                display, configs[0],
                intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
            )
            EGL14.eglMakeCurrent(display, surf, surf, ctx)
            val renderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Unknown"
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surf)
            EGL14.eglDestroyContext(display, ctx)
            EGL14.eglTerminate(display)
            renderer
        } catch (t: Throwable) {
            "Unknown"
        }
    }

    private companion object {
        const val MB = 1024L * 1024L
    }
}
