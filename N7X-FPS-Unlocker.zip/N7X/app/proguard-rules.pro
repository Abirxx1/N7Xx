# Keep rules for release builds. No reflection is used, so nothing extra is needed.
